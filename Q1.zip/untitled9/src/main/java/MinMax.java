public class MinMax {

    public static int Min(int num[]) {
        int min = 99999999;
        for (int i = 0; i < num.length; i++) {
            if (num[i] < min) {
                min = num[i];
            }
        }
        return min;
    }

    public static int Max(int[] num) {
        int max = -999999999;
        for (int i = 0; i < num.length; i++) {
            if (num[i] > max) {
                max = num[i];
            }
        }
        return max;
    }
}