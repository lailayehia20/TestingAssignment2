import java.util.Scanner;

public class EvenOrOdd {

    public static String EvenOddChecker() {

        Scanner reader = new Scanner(System.in);

        int num = reader.nextInt();

        if(num % 2 == 0)
            return "even";
        else
            return "odd";
    }
}