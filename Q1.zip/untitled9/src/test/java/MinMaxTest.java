import org.junit.Test;

import java.io.ByteArrayInputStream;

import static org.junit.Assert.assertTrue;


class MinMaxTest {

    @Test
    public void test1(){
        int x[] = {1,2,3,-1,-10,0,20};
        assertTrue(MinMax.Min(x) == -10);
    }

    @Test
    public void test2(){
        int x[] = {1,2,3,6,10,0,20};
        assertTrue(MinMax.Max(x) == 20);
    }

    @Test
    public void test3(){
        int x[] = {1,2,3,6,10,0,20};
        assertTrue(MinMax.Min(x) == 20);
    }

}
