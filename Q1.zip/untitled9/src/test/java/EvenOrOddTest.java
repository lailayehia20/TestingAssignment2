import org.junit.Test;

import java.io.ByteArrayInputStream;

import static org.junit.Assert.assertTrue;

public class EvenOrOddTest {

 @Test
    public void test1(){
     String x = "50";
     System.setIn(new ByteArrayInputStream(x.getBytes()));
     assertTrue(EvenOrOdd.EvenOddChecker() == "even");
 }

 @Test
 public void test2(){
  String x = "0";
  System.setIn(new ByteArrayInputStream(x.getBytes()));
  assertTrue(EvenOrOdd.EvenOddChecker() == "even");
 }

 @Test
 public void test3(){
  String x = "-10";
  System.setIn(new ByteArrayInputStream(x.getBytes()));
  assertTrue(EvenOrOdd.EvenOddChecker() == "even");
 }

 @Test
 public void test4(){
  String x = "5";
  System.setIn(new ByteArrayInputStream(x.getBytes()));
  assertTrue(EvenOrOdd.EvenOddChecker() == "odd");
 }

 @Test
 public void test5(){
  String x = "-9";
  System.setIn(new ByteArrayInputStream(x.getBytes()));
  assertTrue(EvenOrOdd.EvenOddChecker() == "odd");
 }
}
