import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

class WatchTest {

    Watch watch = new Watch();

    @Test
    void Test1() throws IOException {
        watch.setPressed_buttons("za");
        watch.watch();
        Path realOutput_file = Path.of("ResultingStates.txt");
        String contentOf_realOutput_file = Files.readString(realOutput_file);
        Path expectedOutput_file = Path.of("Test1.txt");
        String contentOf_expectedOutput_file = Files.readString(expectedOutput_file);
        assertTrue(contentOf_expectedOutput_file, contentOf_realOutput_file);
    }

    @Test
    void Test2() throws IOException {
        watch.setPressed_buttons("abd");
        watch.watch();
        Path realOutput_file = Path.of("ResultingStates.txt");
        String contentOf_realOutput_file = Files.readString(realOutput_file);
        Path expectedOutput_file = Path.of("Test2.txt");
        String contentOf_expectedOutput_file = Files.readString(expectedOutput_file);
        assertTrue(contentOf_expectedOutput_file, contentOf_realOutput_file);
    }
    @Test
    void Test3() throws IOException {
        watch.setPressed_buttons("cdb");
        watch.watch();
        Path realOutput_file = Path.of("ResultingStates.txt");
        String contentOf_realOutput_file = Files.readString(realOutput_file);
        Path expectedOutput_file = Path.of("Test3.txt");
        String contentOf_expectedOutput_file = Files.readString(expectedOutput_file);
        assertTrue(contentOf_expectedOutput_file, contentOf_realOutput_file);
    }

    @Test
    void Test4() throws IOException {
        watch.setPressed_buttons("caaaa");
        watch.watch();
        Path realOutput_file = Path.of("ResultingStates.txt");
        String contentOf_realOutput_file = Files.readString(realOutput_file);
        Path expectedOutput_file = Path.of("Test4.txt");
        String contentOf_expectedOutput_file = Files.readString(expectedOutput_file);
        assertTrue(contentOf_expectedOutput_file, contentOf_realOutput_file);
    }

    void Test5() throws IOException {
        watch.setPressed_buttons("");
        watch.watch();
        Path realOutput_file = Path.of("ResultingStates.txt");
        String contentOf_realOutput_file = Files.readString(realOutput_file);
        Path expectedOutput_file = Path.of("Test5.txt");
        String contentOf_expectedOutput_file = Files.readString(expectedOutput_file);
        assertTrue(contentOf_expectedOutput_file, contentOf_realOutput_file);
    }

}