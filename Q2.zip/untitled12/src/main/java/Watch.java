import java.io.*;
import java.util.*;

public class Watch {
    ArrayList<String> Sequence_of_states = new ArrayList<String>();
    String Pressed_buttons;

    public String getPressed_buttons() {
        return Pressed_buttons;
    }

    public void setPressed_buttons(String myInput) {
        this.Pressed_buttons = myInput;
    }

    public void watch() throws IOException {
        String myInput = getPressed_buttons();


        if (myInput.length() == 0) {
            File file = new File("ResultingStates.txt");
            FileOutputStream fos = new FileOutputStream(file);
            PrintWriter x = new PrintWriter(fos);
            Sequence_of_states.add("Empty input");
            x.write(String.valueOf(Sequence_of_states));
            x.flush();
            fos.close();
            x.close();
        }

        else {
            File file = new File("ResultingStates.txt");
            FileOutputStream fos = new FileOutputStream(file);
            PrintWriter writer = new PrintWriter(fos);

            String state = "Normal Display";
            String innerState = "Time";
            int minutes = 0, hours = 0, days = 1, months = 1, years = 2000;
            myInput.toLowerCase();
            for (int i = 0; i < myInput.length(); i++) {
                char currentChar = myInput.charAt(i);
                switch (state) {
                    case "Normal Display":
                        if (currentChar == 'c') {
                            state = "Update";
                            innerState = "min";
                        }

                        if (currentChar == 'b') {
                            state = "Alarm";
                            innerState = "Alarm";
                        }

                        if (currentChar == 'a') {
                            if (innerState == "Time") {
                                innerState = "Date";
                            } else {
                                innerState = "Time";
                            }
                        }

                        if (currentChar == 'd') {
                            Sequence_of_states.add("no action is taken with input d");
                        }
                        break;

                    case "Alarm":
                        if (currentChar == 'a') {
                            if (innerState == "Alarm") {
                                innerState = "Chime";
                            }
                        }

                        if (currentChar == 'b') {
                            Sequence_of_states.add("no action is taken with input b");
                        }

                        if (currentChar == 'c') {
                            Sequence_of_states.add("no action is taken with input c");
                        }

                        if (currentChar == 'd') {
                            state = "Normal Display";
                            innerState = "Time";
                        }
                        break;

                    case "Update":

                        if (currentChar == 'a') {
                            switch (innerState) {
                                case "min":
                                    innerState = "hour";
                                    break;
                                case "hour":
                                    innerState = "day";
                                    break;
                                case "day":
                                    innerState = "month";
                                    break;
                                case "month":
                                    innerState = "year";
                                    break;
                                case "year":
                                    state = "Normal Display";
                                    innerState = "Time";
                                    break;
                            }
                        }

                        if (currentChar == 'b') {
                            switch (innerState) {
                                case "min":
                                    minutes++;
                                    if (minutes == 60) {
                                        minutes = 0;
                                        hours++;
                                        if (hours == 24) {
                                            hours = 0;
                                            days++;
                                            if (days == 31) {
                                                days = 1;
                                                months++;
                                                if (months == 13) {
                                                    months = 1;
                                                    years++;
                                                }
                                            }

                                        }
                                    }
                                case "hour":
                                    hours++;
                                    if (hours == 24) {
                                        hours = 0;
                                        days++;
                                        if (days == 31) {
                                            days = 1;
                                            months++;
                                            if (months == 13) {
                                                months = 1;
                                                years++;
                                            }
                                        }

                                    }
                                case "day":
                                    days++;
                                    if (days == 31) {
                                        days = 1;
                                        months++;
                                        if (months == 13) {
                                            months = 1;
                                            years++;
                                        }
                                    }
                                case "month":
                                    months++;
                                    if (months == 13) {
                                        months = 1;
                                        years++;
                                    }
                                case "year":
                                    years++;

                            }
                        }

                        if (currentChar == 'c') {
                            Sequence_of_states.add("no action is taken with input c");

                        }

                        if (currentChar == 'd') {
                            state = "Normal Display";
                            innerState = "Time";
                        }
                        break;

                }

                Sequence_of_states.add("The Current State is  " + state);
                Sequence_of_states.add("The innerState is " + innerState);
                Sequence_of_states.add("Date " + years + " - " + months + " - " + days);
                Sequence_of_states.add("Time " + hours + " : " + minutes);


            }

            System.out.println(Sequence_of_states);
            writer.write(String.valueOf(Sequence_of_states));
            writer.flush();
            writer.close();
            writer.close();
        }
    }

}
